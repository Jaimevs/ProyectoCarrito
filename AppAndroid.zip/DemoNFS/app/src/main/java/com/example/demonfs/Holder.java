package com.example.demonfs;

import android.widget.ImageView;
import android.widget.TextView;

public class Holder {
    public TextView tvName;
    public TextView tvAddress;
    public ImageView ivDevice;
}
